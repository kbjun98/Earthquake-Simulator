using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static bool hardMode = false;
    public Material darkSkyBox;
    public Light mainLight;
    public Camera playerCamera;
    public GameObject flashLightSpawner;
    public Inventory inventory;
    //public Item flashLight;
    public const float darkFog = 0.7f;
    // Start is called before the first frame update
    void Start()
    {
        Cursor.visible = false;
        //hardMode= true;
        if(hardMode)
        {
            flashLightSpawner.SetActive(false);
            RenderSettings.skybox = darkSkyBox;
            //inventory.addItem(flashLight);
            mainLight.intensity = 0;
            RenderSettings.fog = true;
            RenderSettings.fogDensity = darkFog;
            playerCamera.backgroundColor= Color.black;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.visible = true;
        }
        if(Input.GetMouseButtonDown(0))
        {
            Cursor.visible = false;
        }
    }
}
