using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EarthquakeManager : MonoBehaviour
{
    public float amount;
    public float duration;
    public float cameraShakeTime;
    public float cameraShakeAmount;

    public bool StartEarthquake = false;
    public bool Severe = false;

    private int nextEarthQuakeType;
    private EarthQuake currentEarthQuake;
    private EarthQuake nextEarthQuake;

    public GameObject playerCamera; 
    public GameObject player;

    public static List<EarthquakeObject> eqObjectList = new (); 

    public EarthquakeUIManager euim;
    void Start()
    {
        nextEarthQuake = EarthQuake.weak(amount,duration,cameraShakeTime);
        StartCoroutine(earthQuake());
    }

    private IEnumerator earthQuake()
    {
        currentEarthQuake = nextEarthQuake;
        setNextEarthQuake();
        earthQuakeGravity();
        earthQuakeCamera();
        earthQuakeObject();
        yield return new WaitForSeconds(nextEarthQuake.duration);
        StartCoroutine(earthQuake());
    }

    private void setNextEarthQuake()
    {
        nextEarthQuakeType = Random.Range(0, 10);
        if (nextEarthQuakeType == 0)
        {
            nextEarthQuake = EarthQuake.weak(amount, duration, cameraShakeTime);
            Severe = false;
        }
        else if (nextEarthQuakeType == 9)
        {
            nextEarthQuake = EarthQuake.strong(amount, duration, cameraShakeTime);
            Severe = true;

        }
        else
        {
            nextEarthQuake = EarthQuake.slide(amount, duration, cameraShakeTime);
            Severe = false;
        }
        euim.setNextEarthquake(nextEarthQuake.name, nextEarthQuake.duration);
    }

    private void earthQuakeObject()
    {
        if(currentEarthQuake.type==EarthQuakeType.Strong||currentEarthQuake.type==EarthQuakeType.Weak)
        {
            foreach(EarthquakeObject obj in eqObjectList)
            {
                obj.earthQuake(currentEarthQuake.amount);
            }
        }
    }

    private void earthQuakeCamera()
    {
        if (currentEarthQuake.type == EarthQuakeType.Strong
            || currentEarthQuake.type == EarthQuakeType.Weak)
        {
            StartCoroutine(cameraShake());
        }
    }
    IEnumerator cameraShake()
    {
        float timer = 0;
        Quaternion originRotation = playerCamera.transform.rotation;
        while (timer <= currentEarthQuake.cameraShakeTime)
        {
            playerCamera.transform.Rotate(
                Random.insideUnitSphere *
                currentEarthQuake.amount * cameraShakeAmount);
            timer += Time.deltaTime;
            yield return null;
        }
        playerCamera.transform.rotation= originRotation;
        playerCamera.transform.rotation = Quaternion.LookRotation(playerCamera.transform.forward, -Physics.gravity);

    }

    private void earthQuakeGravity()
    {
        StartCoroutine(changeGravity());
    }

    IEnumerator changeGravity()
    {
        float timer = 0;
        while (timer <= currentEarthQuake.cameraShakeTime)
        {

            Physics.gravity = Vector3.Slerp(
                Physics.gravity, 
                currentEarthQuake.gravity, 
                timer / nextEarthQuake.duration);
            

            playerCamera.transform.rotation = Quaternion.LookRotation(playerCamera.transform.forward,-Physics.gravity);
            timer += Time.deltaTime;
            yield return null;
        }
    }
}
