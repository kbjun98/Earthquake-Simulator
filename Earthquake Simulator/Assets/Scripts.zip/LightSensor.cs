using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightSensor : MonoBehaviour
{
    private GameObject playerCam;
    public Vector3 objPos;

    
    private bool isPlayer = false;

    void Awake()
    {
        playerCam = GameObject.Find("playerCam");
        objPos = gameObject.transform.position;
        
    }

    void Start()
    {
        StartCoroutine(DetectPlayer(objPos, 4f));
    }

    void Update()
    {
        //Debug.Log(gameObject.name + " isPlayer : " + isPlayer);
        //DetectPlayer(objPos, 2f);
        /*
        if (playerCam.GetComponent<ObjectHighlight>().isTargeting && isPlayer)
        {
            gameObject.GetComponent<ObjectOutline>().enabled = true;
            //Debug.Log(gameObject.name + " OUTLINE Enabled");
        }
        */
        if (isPlayer)
        {
            gameObject.GetComponent<ObjectOutline>().enabled = true;
            //Debug.Log(gameObject.name + " OUTLINE Enabled");
        }
        else
        {
            gameObject.GetComponent<ObjectOutline>().enabled = false;
            isPlayer = false;
        }
    }


    IEnumerator DetectPlayer(Vector3 center, float radius)
    {
        Collider[] hitColliders = Physics.OverlapSphere(center, radius);
        int i = 0;

        while (i < hitColliders.Length) 
        {
            if (hitColliders[i].transform.tag == "Player")
            {
                //Debug.Log("Player detected by : " + gameObject.name);
                isPlayer = true;
                break;
            }
            i++;
            isPlayer = false;
        }
        yield return new WaitForSeconds(0.2f);
        StartCoroutine(DetectPlayer(objPos, 4f));
        
    }
}
