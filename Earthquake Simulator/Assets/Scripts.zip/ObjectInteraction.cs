using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectInteraction : MonoBehaviour
{
    public float interactDiastance = 5f;
    private GameObject EventCheck;
    private GameObject EventSystem;
    public GameObject extinguisher;
    
    private Vector3 CameraPos;
    private Inventory inventory;
    //private GameObject temp;

    private bool isHiding = false;
    private bool isCrouched = false;
    
    public bool haveTowel = false;      // public for test
    public bool isWatered = false;
    
    void Awake()
    {
        extinguisher.SetActive(false);
        EventCheck = GameObject.Find("EventCheck");
        EventSystem = GameObject.Find("EventSystem");
        inventory = gameObject.transform.parent.GetComponent<Inventory>();
    }

    void Update()
    {
        CameraPos = gameObject.transform.position;
        if (Input.GetKeyDown(KeyCode.C))
        {
            StartCoroutine(HeadDown());
        }
        if (Input.GetKeyDown(KeyCode.E))
        {
            Debug.Log("pressed E");
            Ray ray = new Ray(transform.position, transform.forward);
            RaycastHit hit;
            Debug.Log("ray casted");
            if (Physics.Raycast(ray, out hit, interactDiastance))
            {
                if (hit.collider.CompareTag("Door"))
                {
                    Debug.Log("ENTER");
                    hit.collider.transform.parent.GetComponent<DoorOpen>().ChangeDoorState();
                    Debug.Log("Enter2");
                }

                if (hit.collider.CompareTag("Elevator"))
                {
                    EventCheck.GetComponent<EventCheck>().escaped_elevator = true;
                    EventSystem.GetComponent<EventManager>().GameOver();
                }

                if (hit.collider.CompareTag("Fire"))
                {
                    Debug.Log("Before off");
                    Destroy(hit.collider.gameObject);
                    Debug.Log("fire off");
                }

                if (hit.collider.CompareTag("Fuse"))
                {
                    Debug.Log("Fuse off");
                    EventCheck.GetComponent<EventCheck>().triggered_electric = true;
                    //레버 효과음 추가
                }
                if (hit.collider.CompareTag("Valve"))
                {
                    Debug.Log("Valve off");
                    EventCheck.GetComponent<EventCheck>().triggered_valve = true;
                    hit.collider.transform.parent.GetComponent<LockValve>().turnValve();
                    //밸브 효과음 추가
                }
                if (hit.collider.CompareTag("Call"))
                {
                    Debug.Log("119 reported");
                    EventCheck.GetComponent<EventCheck>().isReported = true;
                    hit.collider.GetComponent<AudioSource>().enabled = true;
                    // 전화 효과음 추가
                }
                if (hit.collider.CompareTag("Desk") && !isHiding)
                {
                    StartCoroutine(getDown());
                    isHiding = true;
                }
                if (hit.collider.name=="Towel" && hit.collider.CompareTag("Item"))  // 손수건 획득
                {
                    Debug.Log("get towel");
                    haveTowel = true;
                    Destroy(hit.collider.gameObject);
                    inventory.addItem(hit.collider.GetComponent<Item>());
                    // 효과음 추가
                }
                if (hit.collider.name == "Water" && haveTowel)
                {
                    Debug.Log("Water");
                    isWatered = true;
                }
                
            }
        }
        if(isHiding)
            StartCoroutine(getUp());

        if (isCrouched)
            StartCoroutine(HeadUp());
    }

    IEnumerator getDown()
    {
        if(Input.GetKeyDown(KeyCode.E))
            {
                Debug.Log("Hiding");
                transform.parent.position = new Vector3(-5.4f, 0.1f, -6.5f);
                transform.parent.Rotate(0,180,0);
                transform.parent.gameObject.GetComponent<CapsuleCollider>().isTrigger = true;
                transform.parent.gameObject.GetComponent<Rigidbody>().useGravity = false;
                transform.parent.gameObject.GetComponent<PlayerController>().speed = 0;
                //숨기 효과음 추가
            }
        yield return null;
    }

    IEnumerator getUp()
    {
        yield return new WaitForSeconds(0.1f);
        if(isHiding && Input.GetKeyDown(KeyCode.E))
        {
            transform.parent.position = new Vector3(-4.7f, 2.7f, -0.5f);
            transform.parent.gameObject.GetComponent<CapsuleCollider>().isTrigger = false;
            transform.parent.gameObject.GetComponent<Rigidbody>().useGravity = true;
            transform.parent.gameObject.GetComponent<PlayerController>().speed = 20;
            //나오는 효과음 추가
            isHiding = false;
        }
        yield return null;
    }

    IEnumerator HeadUp()
    {
        yield return new WaitForSeconds(0.1f);
        if(isCrouched && Input.GetKeyDown(KeyCode.C))
        {
            Debug.Log("HeadUP");
            gameObject.transform.position = new Vector3(CameraPos.x, CameraPos.y+2.4f,CameraPos.z);
            isCrouched = false;
        }
        yield return null;
    }

    IEnumerator HeadDown()
    {
        if(!isCrouched && Input.GetKeyDown(KeyCode.C))
        {
            Debug.Log("HeadDown");
            gameObject.transform.position = new Vector3(CameraPos.x, CameraPos.y-2.4f,CameraPos.z);
            isCrouched = true;
        }
        yield return null;
    }
}
