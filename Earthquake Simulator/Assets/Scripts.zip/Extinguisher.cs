using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Extinguisher : MonoBehaviour
{

    private AudioSource sound_extinguish;

    void Start()
    {
        sound_extinguish = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            Debug.Log("PRESSED");
            sound_extinguish.Play();
        }
        else
        {
            Debug.Log("NO PRESSED");
            //sound_extinguish.Stop();
        }
        
        
    }
}
