using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Event_escape : MonoBehaviour
{
    public GameObject EventCheck;
    public Image fadeImage;
    private GameObject EventSystem;

    private void Awake()
    {
      EventSystem = GameObject.Find("EventSystem");
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.tag == "Player")
        {
            EventCheck.GetComponent<EventCheck>().escaped_stairs = true;
            Debug.Log("계단으로 탈출.");
            EventSystem.GetComponent<EventManager>().GameOver();
        }
    }
}
