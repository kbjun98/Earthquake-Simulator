using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloorDamage : MonoBehaviour
{
    private void OnCollisionEnter(Collision other)
    {
        if (other.transform.tag == "Player")
        {
            other.gameObject.GetComponent<PlayerHealth>().getDamage();
            Debug.Log("체력 5 감소");
            //EventSystem.GetComponent<EventManager>().GameOver();
        }
    }
}
